Drupal.locale = { 'strings': {"":{"Previous":"Predhodna","Next":"Slede\u0107a"}} };;
